This plugin contains XSLT code for adding syntax highlight to DITA code blocks using the open source project XSLT-HL:
http://sourceforge.net/projects/xslthl/

The licensing for this plugin is considered to be the same as the licensing for the Oxygen WebHelp plugin.
Licensing information for the Oxygen WebHelp plugin can be found in the folder "com.oxygenxml.webhelp"