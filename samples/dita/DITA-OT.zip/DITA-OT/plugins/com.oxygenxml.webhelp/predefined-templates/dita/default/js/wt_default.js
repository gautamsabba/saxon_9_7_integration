// Add some Bootstrap classes when document is ready
$(document).ready(function(){
    $('#webhelp_breadcrumb > ol').addClass('breadcrumb');
    $('#webhelp_breadcrumb ol li>a').addClass('breadcrumb-element');
    
    // Navigational links and print
    $('#topic_navigation_links .navprev>a').addClass("glyphicon glyphicon-arrow-left")
    $('#topic_navigation_links .navnext>a').addClass("glyphicon glyphicon-arrow-right")
    $('#webhelp_print_link a').addClass('glyphicon glyphicon-print');    
});

/**
 * @description Log messages and objects value into browser console
 */
function debug(message, object) {
    object = object || "";
    console.log(message, object);
}

/**
 * @description Highlight searched words
 * @param words {Array} words to be highlighted
 */
function highlightSearchTerm() {
    debug("highlightSearchTerm()");
    var $body = $('.body');
    $body.removeHighlight();

    try {
        var jsonString = $.cookie("searchedWords");
        debug("jsonString: ", jsonString);

        if (jsonString!==undefined && jsonString != "") {
            var words = JSON.parse(jsonString);
            debug("words: ", words);

            for (var i = 0; i < words.length; i++) {
                debug('highlight(' + words[i] + ');');
                $body.highlight(words[i]);
            }
        }
    } catch (e) {
        debug (e);
    }

    var options = {path: "/"};
    $.removeCookie("searchedWords", options);
}
