The demo folder has been deprecated and the following plug-ins have been moved
to plugins folder:

* demo/dita11     -> plugins/org.dita.specialization.dita11
* demo/dita132    -> plugins/org.dita.specialization.dita132
* demo/eclipsemap -> plugins/org.dita.specialization.eclipsemap
* demo/fo         -> plugins/org.dita.pdf2
* demo/tocjs      -> plugins/com.sophos.tocjs

The following plug-ins in the demo folder have been moved to a separate
plug-ins Git repository <https://github.com/dita-ot/ext-plugins>:

* demo/FrameMaker_adapter
* demo/apiref
* demo/authorinfo
* demo/book
* demo/elementref
* demo/enote
* demo/faq
* demo/h2d
* demo/java
* demo/javaapiref
* demo/legacypdf
* demo/music
* demo/thesaurus
* demo/tutorial
* demo/video
