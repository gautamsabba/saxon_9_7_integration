This folder contains a mixture of library tools that are used in several activities, 
and for which it is highly desirable that multiple copies don't proliferate.
They are effectively a Saxon resource so can be exploited from stylesheets invoked by Saxon itself.

It is recommended that from XSLT you reference them via some form of indirection variable.

Current occupants:
 - None -

